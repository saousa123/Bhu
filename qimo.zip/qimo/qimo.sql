/*
Navicat MySQL Data Transfer

Source Server         : localhost_3306
Source Server Version : 50018
Source Host           : localhost:3306
Source Database       : qimo

Target Server Type    : MYSQL
Target Server Version : 50018
File Encoding         : 65001

Date: 2019-01-03 13:34:28
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for fatie
-- ----------------------------
DROP TABLE IF EXISTS `fatie`;
CREATE TABLE `fatie` (
  `id` varchar(255) default NULL,
  `name` varchar(255) default NULL,
  `content` varchar(255) default NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of fatie
-- ----------------------------
INSERT INTO `fatie` VALUES ('789', '456', '456');
INSERT INTO `fatie` VALUES ('123', '咸鱼', '咸鱼33');
INSERT INTO `fatie` VALUES ('456', '咸鱼', '咸鱼22');
INSERT INTO `fatie` VALUES ('789', '咸鱼', '咸鱼11');
INSERT INTO `fatie` VALUES ('963', '咸鱼', '咸鱼11');
INSERT INTO `fatie` VALUES ('852', '咸鱼', '咸鱼32');
INSERT INTO `fatie` VALUES ('741', '咸鱼', '咸鱼2');
INSERT INTO `fatie` VALUES ('523', '咸鱼', '咸鱼5');
INSERT INTO `fatie` VALUES ('646', '咸鱼', '咸鱼4');
INSERT INTO `fatie` VALUES ('7865咸鱼', '咸鱼', '咸鱼3');
INSERT INTO `fatie` VALUES ('咸鱼', '咸鱼232', '咸鱼2');
INSERT INTO `fatie` VALUES ('saou', '老师别挂我', '老师999');
INSERT INTO `fatie` VALUES ('1234', '1111', '222而的翁无');
INSERT INTO `fatie` VALUES ('22222', '3131', '1313');
INSERT INTO `fatie` VALUES ('222', '2332', '332');
INSERT INTO `fatie` VALUES ('22121', '无121', '1111');
INSERT INTO `fatie` VALUES ('66666', '56666', '789456123');
INSERT INTO `fatie` VALUES ('2333', '456', '999999');
INSERT INTO `fatie` VALUES ('123456', '2112', '21321');
INSERT INTO `fatie` VALUES ('1234', '222', '3232');
INSERT INTO `fatie` VALUES ('12', '11111111111', '继电器的期望和我未婚夫和玩法的无痕');
INSERT INTO `fatie` VALUES ('2333', '22222222222', '32312单位为服务');
INSERT INTO `fatie` VALUES ('1', '吴亦凡', '我是最帅的');
INSERT INTO `fatie` VALUES ('2333', '鹿晗来了', '七味都气的期望我的');

-- ----------------------------
-- Table structure for gm
-- ----------------------------
DROP TABLE IF EXISTS `gm`;
CREATE TABLE `gm` (
  `gid` int(11) default NULL,
  `gpw` varchar(255) default NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of gm
-- ----------------------------
INSERT INTO `gm` VALUES ('2333', '12345');

-- ----------------------------
-- Table structure for huifu
-- ----------------------------
DROP TABLE IF EXISTS `huifu`;
CREATE TABLE `huifu` (
  `id` varchar(255) default NULL,
  `name` varchar(255) default NULL,
  `content` varchar(255) default NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of huifu
-- ----------------------------
INSERT INTO `huifu` VALUES ('523', '咸鱼', '');
INSERT INTO `huifu` VALUES ('saou', '老师别挂我', '附议');
INSERT INTO `huifu` VALUES ('1234', '1111', '22');
INSERT INTO `huifu` VALUES ('123456', '2112', '22');
INSERT INTO `huifu` VALUES ('12', '11111111111', '222');
INSERT INTO `huifu` VALUES ('1', '吴亦凡', 'diss');

-- ----------------------------
-- Table structure for img
-- ----------------------------
DROP TABLE IF EXISTS `img`;
CREATE TABLE `img` (
  `uname` varchar(11) NOT NULL,
  `f` float(255,0) default NULL,
  PRIMARY KEY  (`uname`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of img
-- ----------------------------

-- ----------------------------
-- Table structure for tongzhi
-- ----------------------------
DROP TABLE IF EXISTS `tongzhi`;
CREATE TABLE `tongzhi` (
  `content` varchar(255) default NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tongzhi
-- ----------------------------
INSERT INTO `tongzhi` VALUES ('咸鱼');
INSERT INTO `tongzhi` VALUES ('咸鱼突刺');
INSERT INTO `tongzhi` VALUES ('咸鱼突刺咸鱼突刺');
INSERT INTO `tongzhi` VALUES ('咸鱼突刺咸鱼突刺咸鱼突刺');
INSERT INTO `tongzhi` VALUES ('咸鱼突刺咸鱼突刺咸鱼突刺咸鱼突刺');
INSERT INTO `tongzhi` VALUES ('456');
INSERT INTO `tongzhi` VALUES ('快期末啦！！！');
INSERT INTO `tongzhi` VALUES ('456789');
INSERT INTO `tongzhi` VALUES ('完毕');
INSERT INTO `tongzhi` VALUES ('2222321312');
INSERT INTO `tongzhi` VALUES ('鹿晗来了');

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `id` varchar(255) default NULL,
  `pw` varchar(255) default NULL,
  `name` varchar(255) default NULL,
  `content` varchar(255) default NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES ('456', '456', '咸鱼', '咸鱼');
INSERT INTO `user` VALUES ('12345', '123456', '11', '撒');
INSERT INTO `user` VALUES ('saou', '123', 'saou', '233');
INSERT INTO `user` VALUES ('1234', '1234', '陈上', '22321');
INSERT INTO `user` VALUES ('223', '12345', '的地位', '22222');
INSERT INTO `user` VALUES ('', '', '', '');
INSERT INTO `user` VALUES ('', '', '', '');
INSERT INTO `user` VALUES ('66666', '12345', '咸鱼', '咸鱼突刺');
INSERT INTO `user` VALUES ('456', '12345', '555', '555555');
INSERT INTO `user` VALUES ('123456', '123456', '2333', '2333');
INSERT INTO `user` VALUES ('232', '232', '吾问无为谓', '333');
INSERT INTO `user` VALUES ('12', '123', '为鹅鹅鹅', 'www');
INSERT INTO `user` VALUES ('222', '2222', '伪五杀', '大卫的舞');
INSERT INTO `user` VALUES ('1', '123', '吴亦凡', '我是最帅的');
INSERT INTO `user` VALUES ('12334', '222', '鹿晗', '往往·');
INSERT INTO `user` VALUES ('999', '999', '周志豪', '周志豪的选择，你的选择');
