package server;


import java.io.IOException
;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import model.DataConnect;
import model.gm;
import model.huifu;
import model.tie;
import model.tie1;
import model.tongzhi1;
import model.tongzhi2;
import model.user;
import model.users;

public class Server implements Runnable {
	ObjectInputStream ois;
	ObjectOutputStream oos;
	Socket s;
	final int LOGIN = 101;
	final int REG = 102;
	final int GMLOGIN = 103;
	final int FATIE = 104;
	final int HF = 106;
	final int TF = 108;
	public Server() throws IOException, SQLException, ClassNotFoundException{
		ServerSocket ss = new ServerSocket(23456);
		 System.out.println(ss);
		 while(true){
		 s = ss.accept();
		 System.out.println(s);
		 new Thread(this).start();
		 }
	}
	private void login() throws IOException, SQLException, ClassNotFoundException{
		user u = null;
		String id = ois.readUTF();
		String pw = ois.readUTF();
		String sql = "select * from user where id='"+id+"' and pw ='"+pw+"'";
		ResultSet rs = DataConnect.getStatment().executeQuery(sql);
		if(rs.next()){
			u = new user(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4));
		}
		oos.writeObject(u);
		oos.flush();
		
	}
	private void register() throws IOException, SQLException, ClassNotFoundException{
		user u = null;
		String id = ois.readUTF();
		String pw = ois.readUTF();
		String name = ois.readUTF();
		String content = ois.readUTF();
		String sql = "insert into user values('"+id+"','"+pw+"','"+name+"','"+content+"')";
		try {
			DataConnect.getStatment().executeUpdate(sql);
			oos.writeObject(new user(id,pw,name,content));
			oos.flush();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			oos.writeObject(null);
			oos.flush();
		}	
	}
	private void gmlogin() throws IOException, SQLException, ClassNotFoundException{
		gm u = null;
		String gid=ois.readUTF();
		String gpw=ois.readUTF();
		String sql = "select * from gm where gid='"+gid+"' and gpw ='"+gpw+"'";
		ResultSet rs = DataConnect.getStatment().executeQuery(sql);
		if(rs.next()){
			u = new gm(rs.getString(1),rs.getString(2));
		}
		oos.writeObject(u);
		oos.flush();
	}
	private void insert() throws IOException, SQLException, ClassNotFoundException{
		tie u = null;
		String id = ois.readUTF();
		String name=ois.readUTF();
		String content=ois.readUTF();
		String sql = "insert into fatie values('"+id+"','"+name+"','"+content+"')";
		try {
			DataConnect.getStatment().executeUpdate(sql);
			oos.writeObject(new tie(id,name,content));
			oos.flush();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			oos.writeObject(null);
			oos.flush();
		}
	}
	private void hf() throws IOException, SQLException, ClassNotFoundException{
		huifu u = null;
		String id = ois.readUTF();
		String name=ois.readUTF();
		String content=ois.readUTF();
		String sql = "insert into huifu values('"+id+"','"+name+"','"+content+"')";
		try {
			DataConnect.getStatment().executeUpdate(sql);
			oos.writeObject(new huifu(id,name,content));
			oos.flush();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			oos.writeObject(null);
			oos.flush();
		}
	}
	private void tong() throws IOException, SQLException, ClassNotFoundException{
		tongzhi1 u =null;
		String content=ois.readUTF();
		String sql = "insert into tongzhi values('"+content+"')";
		try {
			DataConnect.getStatment().executeUpdate(sql);
			oos.writeObject(new tongzhi1(content));
			oos.flush();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			oos.writeObject(null);
			oos.flush();
		}
	}
	
	@Override
	public void run() {
		// TODO Auto-generated method stub
			try {
				ois = new ObjectInputStream(s.getInputStream());
				oos = new ObjectOutputStream(s.getOutputStream());
				int command=ois.readInt();
				if (command == LOGIN) {
					login();
				}
				if (command ==REG) {
					register();
				}
				if(command==GMLOGIN){
					gmlogin();
				}
				if(command==FATIE){
					insert();
				}
				if(command==105){
					String sql="select * from fatie";
					ResultSet rs = DataConnect.getStatment().executeQuery(sql);
					ArrayList<tie1> tie1s = new ArrayList<tie1>();
					while(rs.next()){
						tie1s.add(new tie1(rs.getString(1),rs.getString(2),rs.getString(3)));
					}
					oos.writeObject(tie1s);
					oos.flush();
				}
				if(command==HF){
					hf();
				}
				if(command==107){
					String sql="select * from tongzhi";
					ResultSet rs = DataConnect.getStatment().executeQuery(sql);
					ArrayList<tongzhi2> tongzhi2s= new ArrayList<tongzhi2>();
					while(rs.next()){
						tongzhi2s.add(new tongzhi2(rs.getString(1)));
					}
					oos.writeObject(tongzhi2s);
					oos.flush();
				}
				if(command==TF){
					tong();
				}
				if(command==109){
					String sql="select * from user";
					ResultSet rs = DataConnect.getStatment().executeQuery(sql);
					ArrayList<users> userss=new ArrayList<users>();
					while(rs.next()){
						userss.add(new users(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4)));
					}
					oos.writeObject(userss);
					oos.flush();
					
				}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} 

		
	}
	

	public static void main(String[] args){
		try {
			new Server();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
