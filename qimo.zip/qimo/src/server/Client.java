package server;

import java.io.IOException
;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.ArrayList;

import model.gm;
import model.huifu;
import model.tie;
import model.tie1;
import model.tongzhi1;
import model.tongzhi2;
import model.user;
import model.users;

public class Client {
	static ObjectOutputStream oos;
	static ObjectInputStream ois;
	final static int LOGIN = 101;
	final static int REG = 102;
	final static int GMLOGIN = 103;
	final static int FATIE = 104;
	final static int HF = 106;
	final static int TF = 108;
	
	
	public Client() throws UnknownHostException, IOException{
		Socket s = new Socket("10.51.160.87",23456);
		oos = new ObjectOutputStream(s.getOutputStream());
		ois = new ObjectInputStream(s.getInputStream());
	}
	public user login(String id,String pw) throws IOException, ClassNotFoundException{
		oos.writeInt(LOGIN);
		oos.flush();
		oos.writeUTF(id);
		oos.flush();
		oos.writeUTF(pw);
		oos.flush();
		return (user)ois.readObject();
		
	}
	public user register(String id,String pw,String name,String content) throws IOException, ClassNotFoundException{
		oos.writeInt(REG);
		oos.flush();
		oos.writeUTF(id);
		oos.flush();
		oos.writeUTF(pw);
		oos.flush();
		oos.writeUTF(name);
		oos.flush();
		oos.writeUTF(content);
		oos.flush();
		return (user)ois.readObject();
	}
	public gm gmlogin(String gid,String gpw) throws IOException, ClassNotFoundException{
		oos.writeInt(GMLOGIN);
		oos.flush();
		oos.writeUTF(gid);
		oos.flush();
		oos.writeUTF(gpw);
		oos.flush();
		return (gm)ois.readObject();
	}
	public tie insert(String id,String name,String content) throws IOException, ClassNotFoundException{
		oos.writeInt(FATIE);
		oos.flush();
		oos.writeUTF(id);
		oos.flush();
		oos.writeUTF(name);
		oos.flush();
		oos.writeUTF(content);
		oos.flush();
		return (tie)ois.readObject();
	}
	public huifu hf(String id,String name,String content) throws IOException, ClassNotFoundException{
		oos.writeInt(HF);
		oos.flush();
		oos.writeUTF(id);
		oos.flush();
		oos.writeUTF(name);
		oos.flush();
		oos.writeUTF(content);
		oos.flush();
		return (huifu)ois.readObject();
	}
	public ArrayList<tie1> view() throws IOException, ClassNotFoundException{
		oos.writeInt(105);
		oos.flush();
		ArrayList<tie1> tie1s =(ArrayList<tie1>) ois.readObject();
		return tie1s;	
	}
	public tongzhi1 tong(String content) throws IOException, ClassNotFoundException{
		oos.writeInt(TF);
		oos.flush();
		oos.writeUTF(content);
		oos.flush();
		return (tongzhi1)ois.readObject();
		
	}
	public ArrayList<tongzhi2> view1() throws IOException, ClassNotFoundException{
		oos.writeInt(107);
		oos.flush();
		ArrayList<tongzhi2> tongzhi2s=(ArrayList<tongzhi2>) ois.readObject();
		return tongzhi2s;
	}
	public ArrayList<users> view2() throws IOException, ClassNotFoundException{
		oos.writeInt(109);
		oos.flush();
		ArrayList<users> userss=(ArrayList<users>)ois.readObject();
		return userss;
	}

}
