/*
 * mainview.java
 *
 * Created on __DATE__, __TIME__
 */

package view;

/**
 *
 * @author  __USER__
 */
public class mainview extends javax.swing.JFrame {

	/** Creates new form mainview */
	public mainview() {
		initComponents();
		this.setLocationRelativeTo(null);
	}

	//GEN-BEGIN:initComponents
	// <editor-fold defaultstate="collapsed" desc="Generated Code">
	private void initComponents() {

		jLayeredPane1 = new javax.swing.JLayeredPane();
		jButton12 = new javax.swing.JButton();
		jButton10 = new javax.swing.JButton();
		jButton9 = new javax.swing.JButton();
		jButton8 = new javax.swing.JButton();
		jButton7 = new javax.swing.JButton();
		jButton6 = new javax.swing.JButton();
		jButton5 = new javax.swing.JButton();
		jButton4 = new javax.swing.JButton();
		jButton2 = new javax.swing.JButton();
		jButton1 = new javax.swing.JButton();
		jLabel3 = new javax.swing.JLabel();
		jLabel2 = new javax.swing.JLabel();
		jButton3 = new javax.swing.JButton();
		jLabel1 = new javax.swing.JLabel();

		setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

		jButton12.setBackground(new java.awt.Color(255, 255, 255));
		jButton12.setForeground(new java.awt.Color(0, 153, 255));
		jButton12.setText("\u5e7f\u544a\u9875\u9762");
		jButton12.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jButton12ActionPerformed(evt);
			}
		});
		jButton12.setBounds(260, 140, 100, 50);
		jLayeredPane1.add(jButton12, javax.swing.JLayeredPane.DEFAULT_LAYER);

		jButton10.setBackground(new java.awt.Color(255, 255, 255));
		jButton10.setForeground(new java.awt.Color(0, 153, 255));
		jButton10.setText("\u67e5\u770b\u901a\u77e5");
		jButton10.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jButton10ActionPerformed(evt);
			}
		});
		jButton10.setBounds(70, 530, 230, 29);
		jLayeredPane1.add(jButton10, javax.swing.JLayeredPane.DEFAULT_LAYER);

		jButton9.setBackground(new java.awt.Color(255, 255, 255));
		jButton9.setForeground(new java.awt.Color(0, 153, 255));
		jButton9.setText("\u67e5\u770b\u81ea\u5df1\u7684\u5e16\u5b50");
		jButton9.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jButton9ActionPerformed(evt);
			}
		});
		jButton9.setBounds(70, 490, 230, 29);
		jLayeredPane1.add(jButton9, javax.swing.JLayeredPane.DEFAULT_LAYER);

		jButton8.setBackground(new java.awt.Color(255, 255, 255));
		jButton8.setForeground(new java.awt.Color(0, 153, 255));
		jButton8.setText("\u67e5\u770b\u6240\u6709\u8d34\u5b50");
		jButton8.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jButton8ActionPerformed(evt);
			}
		});
		jButton8.setBounds(70, 450, 230, 29);
		jLayeredPane1.add(jButton8, javax.swing.JLayeredPane.DEFAULT_LAYER);

		jButton7.setBackground(new java.awt.Color(255, 255, 255));
		jButton7.setForeground(new java.awt.Color(0, 153, 255));
		jButton7.setText("\u67e5\u770b\u6700\u65b0\u7684\u5e16\u5b50");
		jButton7.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jButton7ActionPerformed(evt);
			}
		});
		jButton7.setBounds(70, 410, 230, 29);
		jLayeredPane1.add(jButton7, javax.swing.JLayeredPane.DEFAULT_LAYER);

		jButton6.setBackground(new java.awt.Color(255, 255, 255));
		jButton6.setForeground(new java.awt.Color(0, 153, 255));
		jButton6.setText("\u5173\u6ce8\u7684\u5e16\u5b50");
		jButton6.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jButton6ActionPerformed(evt);
			}
		});
		jButton6.setBounds(70, 370, 230, 29);
		jLayeredPane1.add(jButton6, javax.swing.JLayeredPane.DEFAULT_LAYER);

		jButton5.setBackground(new java.awt.Color(255, 255, 255));
		jButton5.setForeground(new java.awt.Color(0, 153, 255));
		jButton5.setText("\u5173\u6ce8\u7684\u7528\u6237");
		jButton5.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jButton5ActionPerformed(evt);
			}
		});
		jButton5.setBounds(70, 330, 230, 29);
		jLayeredPane1.add(jButton5, javax.swing.JLayeredPane.DEFAULT_LAYER);

		jButton4.setBackground(new java.awt.Color(255, 255, 255));
		jButton4.setForeground(new java.awt.Color(0, 153, 255));
		jButton4.setText("\u6700\u8fd1\u6e38\u89c8");
		jButton4.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jButton4ActionPerformed(evt);
			}
		});
		jButton4.setBounds(70, 290, 230, 29);
		jLayeredPane1.add(jButton4, javax.swing.JLayeredPane.DEFAULT_LAYER);

		jButton2.setBackground(new java.awt.Color(255, 255, 255));
		jButton2.setForeground(new java.awt.Color(0, 153, 255));
		jButton2.setText("\u4fee\u6539\u4e2a\u4eba\u4fe1\u606f");
		jButton2.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jButton2ActionPerformed(evt);
			}
		});
		jButton2.setBounds(70, 210, 230, 29);
		jLayeredPane1.add(jButton2, javax.swing.JLayeredPane.DEFAULT_LAYER);

		jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/img/u.jpg"))); // NOI18N
		jButton1.setBounds(10, 70, 100, 90);
		jLayeredPane1.add(jButton1, javax.swing.JLayeredPane.DEFAULT_LAYER);

		jLabel3.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 16));
		jLabel3.setForeground(new java.awt.Color(255, 255, 255));
		jLabel3.setText("Holle! \u4f60\u597d\uff01");
		jLabel3.setBounds(270, 80, 100, 22);
		jLayeredPane1.add(jLabel3, javax.swing.JLayeredPane.DEFAULT_LAYER);

		jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/img/logo.png"))); // NOI18N
		jLabel2.setBounds(0, 0, 370, 60);
		jLayeredPane1.add(jLabel2, javax.swing.JLayeredPane.DEFAULT_LAYER);

		jButton3.setBackground(new java.awt.Color(255, 255, 255));
		jButton3.setForeground(new java.awt.Color(0, 153, 255));
		jButton3.setText("\u53d1\u5e16");
		jButton3.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jButton3ActionPerformed(evt);
			}
		});
		jButton3.setBounds(70, 250, 230, 29);
		jLayeredPane1.add(jButton3, javax.swing.JLayeredPane.DEFAULT_LAYER);

		jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/img/5.jpg"))); // NOI18N
		jLabel1.setBounds(0, 0, 370, 780);
		jLayeredPane1.add(jLabel1, javax.swing.JLayeredPane.DEFAULT_LAYER);

		javax.swing.GroupLayout layout = new javax.swing.GroupLayout(
				getContentPane());
		getContentPane().setLayout(layout);
		layout.setHorizontalGroup(layout.createParallelGroup(
				javax.swing.GroupLayout.Alignment.LEADING).addComponent(
				jLayeredPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 370,
				javax.swing.GroupLayout.PREFERRED_SIZE));
		layout.setVerticalGroup(layout.createParallelGroup(
				javax.swing.GroupLayout.Alignment.LEADING).addComponent(
				jLayeredPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 780,
				Short.MAX_VALUE));

		pack();
	}// </editor-fold>
	//GEN-END:initComponents

	private void jButton12ActionPerformed(java.awt.event.ActionEvent evt) {
		new guanggao().setVisible(true);
		this.dispose();
	}

	private void jButton10ActionPerformed(java.awt.event.ActionEvent evt) {
		new tz().setVisible(true);
		this.dispose();
	}

	private void jButton9ActionPerformed(java.awt.event.ActionEvent evt) {
		new suoyoutie().setVisible(true);
		this.dispose();
		// TODO add your handling code here:
	}

	private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {
		new suoyoutie().setVisible(true);
		this.dispose();
	}

	private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {
		new zuixintie().setVisible(true);
		this.dispose();
	}

	private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {
		new guanzhutiezi().setVisible(true);
		this.dispose();
	}

	private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {
		new gaunzhuyonghu().setVisible(true);
		this.dispose();
	}

	private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {
		new youlan().setVisible(true);
		this.dispose();
	}

	private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {
		new fatie().setVisible(true);
		this.dispose();
	}

	private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {
		new xiugaixinxi().setVisible(true);
		this.dispose();
	}

	/**
	 * @param args the command line arguments
	 */
	public static void main(String args[]) {
		java.awt.EventQueue.invokeLater(new Runnable() {
			public void run() {
				new mainview().setVisible(true);
			}
		});
	}

	//GEN-BEGIN:variables
	// Variables declaration - do not modify
	private javax.swing.JButton jButton1;
	private javax.swing.JButton jButton10;
	private javax.swing.JButton jButton12;
	private javax.swing.JButton jButton2;
	private javax.swing.JButton jButton3;
	private javax.swing.JButton jButton4;
	private javax.swing.JButton jButton5;
	private javax.swing.JButton jButton6;
	private javax.swing.JButton jButton7;
	private javax.swing.JButton jButton8;
	private javax.swing.JButton jButton9;
	private javax.swing.JLabel jLabel1;
	private javax.swing.JLabel jLabel2;
	private javax.swing.JLabel jLabel3;
	private javax.swing.JLayeredPane jLayeredPane1;
	// End of variables declaration//GEN-END:variables

}