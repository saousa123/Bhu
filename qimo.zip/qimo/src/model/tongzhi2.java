package model;

import java.io.IOException;
import java.io.Serializable;
import java.net.UnknownHostException;
import java.util.ArrayList;

import server.Client;

public class tongzhi2 implements Serializable{
	private String content;

	public tongzhi2(String content) {
		super();
		this.content = content;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}
	public tongzhi2(){
		
	}
	public ArrayList<tongzhi2> view1() throws UnknownHostException, IOException, ClassNotFoundException{
		Client c = new Client();
		return c.view1();
	}

}
