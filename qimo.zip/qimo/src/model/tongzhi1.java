package model;

import java.io.Serializable;

public class tongzhi1 implements Serializable{
	private String content;

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public tongzhi1(String content) {
		super();
		this.content = content;
	}

}
