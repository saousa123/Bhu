package model;

import java.io.IOException;
import java.io.Serializable;
import java.net.UnknownHostException;
import java.util.ArrayList;

import server.Client;

public class users implements Serializable{
	private String id;
	private String pw;
	private String name;
	private String content;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getPw() {
		return pw;
	}
	public void setPw(String pw) {
		this.pw = pw;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public users(String id, String pw, String name, String content) {
		super();
		this.id = id;
		this.pw = pw;
		this.name = name;
		this.content = content;
	}
	public users(){
		
	}
	public ArrayList<users> view2() throws UnknownHostException, IOException, ClassNotFoundException{
		Client c =new Client();
		return c.view2();
		
	}

}
