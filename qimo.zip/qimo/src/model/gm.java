package model;

import java.io.Serializable;

public class gm implements Serializable{
	private String gid;
	private String gpw;
	public gm(String gid, String gpw) {
		super();
		this.gid = gid;
		this.gpw = gpw;
	}
	public String getGid() {
		return gid;
	}
	public void setGid(String gid) {
		this.gid = gid;
	}
	public String getGpw() {
		return gpw;
	}
	public void setGpw(String gpw) {
		this.gpw = gpw;
	}
	

}
